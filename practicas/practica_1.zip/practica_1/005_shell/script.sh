#!/bin/bash
gcc main.c tiempo.c
./a.out 100 < n10m.txt >>sal.txt
./a.out 1000 < n10m.txt >>sal.txt
./a.out 5000 < n10m.txt >>sal.txt
./a.out 10000 < n10m.txt >>sal.txt
./a.out 50000 < n10m.txt >>sal.txt
./a.out 100000 < n10m.txt >>sal.txt
./a.out 200000 < n10m.txt >>sal.txt
./a.out 400000 < n10m.txt >>sal.txt
./a.out 600000 < n10m.txt >>sal.txt
./a.out 800000 < n10m.txt >>sal.txt
./a.out 1000000 < n10m.txt >>sal.txt
./a.out 2000000 < n10m.txt >>sal.txt
./a.out 3000000 < n10m.txt >>sal.txt
./a.out 4000000 < n10m.txt >>sal.txt
./a.out 5000000 < n10m.txt >>sal.txt
./a.out 6000000 < n10m.txt >>sal.txt
./a.out 7000000 < n10m.txt >>sal.txt
./a.out 8000000 < n10m.txt >>sal.txt
./a.out 9000000 < n10m.txt >>sal.txt
./a.out 10000000 < n10m.txt >>sal.txt
