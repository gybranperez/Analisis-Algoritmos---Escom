gcc main.c tiempo.c
./a.out 100 < numeros10millones.txt >>sal.txt
./a.out 1000 < numeros10millones.txt >>sal.txt
./a.out 5000 < numeros10millones.txt >>sal.txt
./a.out 10000 < numeros10millones.txt >>sal.txt
./a.out 50000 < numeros10millones.txt >>sal.txt
./a.out 100000 < numeros10millones.txt >>sal.txt
./a.out 200000 < numeros10millones.txt >>sal.txt
./a.out 400000 < numeros10millones.txt >>sal.txt
./a.out 600000 < numeros10millones.txt >>sal.txt
./a.out 800000 < numeros10millones.txt >>sal.txt
./a.out 1000000 < numeros10millones.txt >>sal.txt
./a.out 2000000 < numeros10millones.txt >>sal.txt
./a.out 3000000 < numeros10millones.txt >>sal.txt
./a.out 4000000 < numeros10millones.txt >>sal.txt
./a.out 5000000 < numeros10millones.txt >>sal.txt
